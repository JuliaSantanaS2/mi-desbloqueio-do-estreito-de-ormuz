// app.js — Lógica do Web Dashboard V23
console.log("🚀 Dashboard JS V23 (Persistência Real, Atendendo Universal & Fila Pura)");

var WS_URL = 'ws://' + location.host + '/ws';
var ws, reconnectTimer;

var globalReqMap = {};
var assignedTimeMap = {};
var droneMapGlobal = {};
var lastGs = null;

// GARANTE QUE DRONES APAGADOS CONTINUEM APAGADOS MESMO APÓS F5
var ignoredDrones = JSON.parse(localStorage.getItem('ignoredDrones') || '{}');

var globalSensorTS = {};
var globalBrokerTS = {};
var sensorRenderTick = {};
var brokerRenderTick = {};

var dashboardTick = 0;
setInterval(function() { 
    dashboardTick++; 
    if (lastGs) render(lastGs); 
}, 1000);

function showTab(name, el) {
  document.querySelectorAll('.tab').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('.page').forEach(function(p){ p.classList.remove('active'); });
  el.classList.add('active');
  document.getElementById('page-' + name).classList.add('active');
}

function connect() {
  ws = new WebSocket(WS_URL);
  ws.onopen = function() { setBadge(true); clearTimeout(reconnectTimer); };
  ws.onmessage = function(e) { 
      try { var data = JSON.parse(e.data); lastGs = data; render(data); } catch(x) {} 
  };
  ws.onclose = function() { setBadge(false); reconnectTimer = setTimeout(connect, 3000); };
}

function setBadge(on) {
  var dot = document.getElementById('wsdot'); var lbl = document.getElementById('wslbl');
  if(dot) dot.className = on ? 'on' : 'off';
  if(lbl) lbl.textContent = on ? 'Tempo real' : 'Reconectando...';
}

function requestStatusRank(status) {
  switch (status) { case 'DONE': return 4; case 'ASSIGNED': return 3; case 'LOCKED': return 2; case 'PENDING': return 1; default: return 0; }
}

function mergeRequestState(existing, candidate) {
  if (!existing) return candidate;
  var candTs = candidate.lamport_ts || 0; var exisTs = existing.lamport_ts || 0;
  if (candTs > exisTs) return candidate; if (candTs < exisTs) return existing;
  var rankExisting = requestStatusRank(existing.status); var rankCandidate = requestStatusRank(candidate.status);
  if (rankCandidate !== rankExisting) { return rankCandidate > rankExisting ? candidate : existing; }
  return candidate;
}

function clearLostDrones() {
    Object.keys(droneMapGlobal).forEach(function(id) {
        if (droneMapGlobal[id].status === 'LOST') {
            ignoredDrones[id] = true;
        }
    });
    localStorage.setItem('ignoredDrones', JSON.stringify(ignoredDrones));
    if (lastGs) render(lastGs);
}

function clearRequests() {
  fetch('/api/clear-requests', { method: 'POST' }).then(function(resp) { return resp.json(); }).then(function(data) {
      if (data && data.ok) { globalReqMap = {}; assignedTimeMap = {}; if(lastGs) render(lastGs); }
  }).catch(function(err) {});
}

function createDroneCardHtml(d, missionMap) {
  var mtext = 'Livre';
  var dStatus = d.status;

  if (dStatus === 'BUSY') {
      if (d.mission_desc === 'Retornando para a base') {
          mtext = 'Retornando para a base';
          dStatus = 'RETURNING';
      } else {
          // TAG PADRONIZADA: Atendendo...
          mtext = 'Atendendo...';
      }
  } else if (dStatus === 'LOST') {
      mtext = 'Sem comunicação';
  }
  var mcls = (dStatus === 'BUSY') ? 'active' : (dStatus === 'RETURNING' ? 'returning' : '');

  return '<div class="dcard ' + dStatus + '">' +
    '<div class="davt ' + dStatus + '">&#128641;<span class="dpulse ' + dStatus + '"></span></div>' +
    '<div class="dinfo"><div class="dname">' + d.id + '</div><div class="dbase">Base Atual: ' + d.base_id + ' &middot; Setor ' + (d.sector_id || '?') + '</div><div class="dmission ' + mcls + '">' + mtext + '</div></div>' +
    '<span class="dst ' + dStatus + '">' + dStatus + '</span></div>';
}

function render(gs) {
  try {
    if (!gs || !gs.sectors) return;
    
    var sectors = gs.sectors.slice().sort(function(a,b){ return (a.sector_id || "") < (b.sector_id || "") ? -1 : 1; });
    var droneMap = {};
    sectors.forEach(function(sec) {
      (sec.drones || []).forEach(function(d) {
        if (!d || !d.id) return;
        var prev = droneMap[d.id];
        if (!prev || new Date(d.last_seen) > new Date(prev.last_seen)) droneMap[d.id] = d;
      });
    });
    droneMapGlobal = droneMap;
    
    var allDrones = Object.keys(droneMap).sort().map(function(k){ return droneMap[k]; });

    // Restaura drones que voltaram a ficar online e os remove da lista de ignorados do cache
    allDrones.forEach(function(d) {
        if (d.status !== 'LOST' && ignoredDrones[d.id]) {
            delete ignoredDrones[d.id];
            localStorage.setItem('ignoredDrones', JSON.stringify(ignoredDrones));
        }
    });

    // Aplica o filtro final baseado no cache
    allDrones = allDrones.filter(function(d) { return d && !ignoredDrones[d.id]; });

    var currentReqs = {};
    sectors.forEach(function(sec) {
      if (sec.active_sensors) { Object.keys(sec.active_sensors).forEach(function(sid) { var ts = sec.active_sensors[sid]; var n = sid.toUpperCase(); if (!globalSensorTS[n] || ts > globalSensorTS[n]) { globalSensorTS[n] = ts; sensorRenderTick[n] = dashboardTick; } }); }
      if (sec.active_brokers) { Object.keys(sec.active_brokers).forEach(function(bid) { var ts = sec.active_brokers[bid]; var n = bid.toUpperCase(); if (!globalBrokerTS[n] || ts > globalBrokerTS[n]) { globalBrokerTS[n] = ts; brokerRenderTick[n] = dashboardTick; } }); }
      (sec.queue || []).forEach(function(r) { if (!r || !r.id) return; currentReqs[r.id] = true; globalReqMap[r.id] = mergeRequestState(globalReqMap[r.id], r); });
    });

    Object.keys(globalReqMap).forEach(function(id) { if (!currentReqs[id]) { delete globalReqMap[id]; delete assignedTimeMap[id]; } });

    // DEDUPLICAÇÃO ESTRITA PARA A LISTA DE ATENDENDO
    var assigned = [];
    var seenDrone = {};
    var seenReq = {};
    
    var allQueue = Object.keys(globalReqMap).map(function(k) { return globalReqMap[k]; }).filter(function(r){ 
      if (!r || r.status === 'DONE') return false; 
      
      if (r.status === 'ASSIGNED' && r.assigned_to) {
          if (seenDrone[r.assigned_to] || seenReq[r.id]) return false; // Impede duplicação!
          
          var d = droneMap[r.assigned_to]; 
          if (d && (d.mission_desc === 'Retornando para a base' || d.status === 'IDLE' || d.status === 'LOST')) return false; 
          
          seenDrone[r.assigned_to] = true;
          seenReq[r.id] = true;
          assigned.push(r);
      }
      return true; 
    });

    var pending = allQueue.filter(function(r){ return r.status==='PENDING'||r.status==='LOCKED'; });
    var missionMap = {};
    assigned.forEach(function(r){ if (r.assigned_to) missionMap[r.assigned_to] = r; });

    var idle=0, busy=0, lost=0;
    allDrones.forEach(function(d){ if (d.status==='IDLE') idle++; else if (d.status==='BUSY') busy++; else lost++; });
    
    setText('st-tot', allDrones.length); setText('st-idl', idle); setText('st-bsy', busy); setText('st-lst', lost); setText('st-q', pending.length);

    var aHtml = renderAssignedQueue(assigned); var pHtml = renderPendingQueue(pending);
    var aq1 = document.getElementById('assigned-queue'); if(aq1) aq1.innerHTML = aHtml;
    var pq1 = document.getElementById('pending-queue'); if(pq1) pq1.innerHTML = pHtml;
    var dHtml = renderDroneSidebar(allDrones, missionMap);
    var d1 = document.getElementById('drone-sidebar'); if(d1) d1.innerHTML = dHtml;

    var baseMap = buildBaseMap(sectors, allDrones);
    var sGrid = document.getElementById('sensor-grid');
    if(sGrid) sGrid.innerHTML = sectors.map(function(sec){ return renderSensorCard(sec, globalSensorTS, globalBrokerTS, allQueue, sensorRenderTick, brokerRenderTick); }).join('');

    var baseIds = ['A','B','C','D'];
    var bGrid = document.getElementById('base-grid');
    if(bGrid) bGrid.innerHTML = baseIds.map(function(id){ return renderBaseCard(id, baseMap, allDrones, missionMap); }).join('');
  } catch (err) {}
}

function renderSensorCard(sec, sensorTS, brokerTS, allQueue, sensorTick, brokerTick) {
  var id = sec.sector_id || "?";
  var dynamicSensors = []; if (sec.active_sensors) { dynamicSensors = Object.keys(sec.active_sensors).map(function(k){ return k.toUpperCase(); }); }
  var sensors = ['SENSOR-'+id+'-1', 'SENSOR-'+id+'-2'];
  dynamicSensors.forEach(function(s) { if (sensors.indexOf(s) === -1) sensors.push(s); });
  
  var brokerKey = 'BROKER-' + id;
  var brokerAlive = (brokerTS[brokerKey] || 0) > 0 && (dashboardTick - (brokerTick[brokerKey] || 0)) < 15;
  
  var sensorHtml = sensors.map(function(sid) {
    var lastTS = sensorTS[sid] || 0;
    var alive = lastTS > 0 && (dashboardTick - (sensorTick[sid] || 0)) < 15; 
    if (!brokerAlive && alive) brokerAlive = true; 

    var sType = "ND"; var sTypeColor = "var(--tm)";
    var sensorStatus = alive ? 'ONLINE' : 'OFFLINE'; var sensorStatusColor = alive ? 'var(--gr)' : 'var(--re)';
    
    for (var i=0; i<allQueue.length; i++) {
        if ((allQueue[i].sensor_id || "").toUpperCase() === sid) {
            sType = allQueue[i].type === "CRITICAL" ? "CRÍTICO" : "NORMAL";
            if (allQueue[i].description && allQueue[i].description.indexOf('[RECUPERADA]') !== -1) { sType = "FALHA"; }
            sTypeColor = sType === "CRÍTICO" ? "var(--re)" : (sType === "FALHA" ? "var(--re)" : "var(--ye)"); break;
        }
    }
    return '<div class="spill '+(alive?'alive':'dead')+'"><span class="sdot"></span>' + sid + ' <span style="color:'+sensorStatusColor+'; margin-left:10px; font-weight:bold;">['+sensorStatus+']</span> <span style="color:'+sTypeColor+'; margin-left:10px; font-weight:bold;">['+sType+']</span> <span style="color:var(--tm); float:right;">'+(lastTS > 0 ? 'TS: '+lastTS : 'sem dados')+'</span></div>';
  }).join('');

  var st = brokerAlive ? 'online' : 'offline';
  return '<div class="card '+st+'"><div class="ch"><div class="ctitle"><div class="cbadge '+id+'">'+id+'</div><div><div class="cname">Área Sensor '+id+'</div><div class="csub">broker-'+id+' &middot; sensores</div></div></div><span class="cst '+st+'">'+st+'</span></div><div class="cbody"><div><div class="st">Status dos Componentes</div><div class="sensor-row"><div class="spill '+(brokerAlive?'alive':'dead')+'"><span class="sdot"></span>broker-'+id+' '+(brokerAlive?'ONLINE':'OFFLINE')+'</div>'+sensorHtml+'</div></div></div></div>';
}

function buildBaseMap(sectors, allDrones) {
  var map = {}; ['a','b','c','d'].forEach(function(id) { map['base-' + id] = { id: 'base-' + id, sectorId: id.toUpperCase(), online: false, drones: [] }; });
  sectors.forEach(function(sec) { var bid = 'base-' + (sec.sector_id || '').toLowerCase(); if (map[bid]) map[bid].online = sec.online; });
  sectors.forEach(function(sec) { if (!sec.online) return; (sec.bases || []).forEach(function(b) { var bid = (b.id || '').toLowerCase(); if (map[bid] && b.status === 'OFFLINE') map[bid].online = false; }); });
  allDrones.forEach(function(d){ var dBaseId = (d.base_id||'').toLowerCase(); if (dBaseId && map[dBaseId]) map[dBaseId].drones.push(d); }); return map;
}

function renderBaseCard(sectorId, baseMap, allDrones, missionMap) {
  var bid = 'base-' + sectorId.toLowerCase(); var base = baseMap[bid] || { id: bid, sectorId: sectorId, online: false, drones: [] };
  var st = base.online ? 'online' : 'offline';
  var droneHtml = base.drones.length === 0 ? '<div class="empty" style="text-align:center; padding:15px; color:var(--td); background:var(--s2); border-radius:8px; border: 1px dashed var(--b1);">' + (base.online ? 'Nenhum drone posicionado nesta base.' : 'Base Offline') + '</div>' : base.drones.map(function(d){ return createDroneCardHtml(d, missionMap); }).join('');
  return '<div class="card '+st+'"><div class="ch"><div class="ctitle"><div class="cbadge '+sectorId+'">'+sectorId+'</div><div><div class="cname">Base '+sectorId.toUpperCase()+'</div><div class="csub">'+bid+'</div></div></div><span class="cst '+st+'">'+st+'</span></div><div class="cbody"><div><div class="st">Drone(s) presentes nesta base</div>'+droneHtml+'</div></div></div>';
}

function renderDroneSidebar(allDrones, missionMap) {
  return allDrones.length === 0 ? '<div class="empty">Aguardando drones...</div>' : allDrones.map(function(d) { return createDroneCardHtml(d, missionMap); }).join('');
}

function renderAssignedQueue(assigned) {
  if (assigned.length === 0) return '<div class="empty">Nenhuma &#10003;</div>';
  assigned.forEach(function(r) { if (r && r.id && !assignedTimeMap[r.id]) assignedTimeMap[r.id] = dashboardTick; });
  assigned.sort(function(a, b) { return (assignedTimeMap[a.id]||0) - (assignedTimeMap[b.id]||0); });
  return assigned.map(function(r){ return '<div class="qi'+(r.type==='CRITICAL'?' cr':'')+'"><div class="qsec '+r.sector_id+'">'+r.sector_id+'</div><span class="badge ASSIGNED">ATEND.</span><span class="qdesc"><strong>'+(r.assigned_to||'Desc.')+'</strong> &rarr; '+r.sensor_id+'</span></div>'; }).join('');
}

function renderPendingQueue(pending) {
  if (pending.length === 0) return '<div class="empty">Nenhuma &#10003;</div>';
  pending.sort(function(a, b) {
    if (!a) return 1; if (!b) return -1;
    if (a.priority !== b.priority) return a.priority - b.priority;
    if (a.lamport_ts !== b.lamport_ts) return a.lamport_ts - b.lamport_ts;
    return a.id < b.id ? -1 : (a.id > b.id ? 1 : 0);
  });
  return pending.map(function(r){
    var displayType = r.type === 'CRITICAL' ? 'CRÍTICO' : r.type; var badgeClass = r.type; var cr = r.type==='CRITICAL' ? ' cr' : '';
    if (r.description && r.description.indexOf('[RECUPERADA]') !== -1) { displayType = 'FALHA'; badgeClass = 'FALHA'; cr = ' cr'; }
    return '<div class="qi'+cr+'"><div class="qsec '+r.sector_id+'">'+r.sector_id+'</div><span class="badge '+badgeClass+'">'+displayType+'</span><span class="qdesc"><strong>'+r.sensor_id+'</strong> &middot; '+(r.description||'').substring(0,35)+'</span></div>';
  }).join('');
}

function setText(id, v) { var e = document.getElementById(id); if (e) e.textContent = v; }
connect();
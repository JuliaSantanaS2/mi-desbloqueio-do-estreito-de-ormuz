package main

import (
	"drone-system/internal/models"
	"drone-system/internal/network"
	"encoding/json"
	"sync"
	"time"
)

var dispatchMu sync.Mutex

func startDispatcher() {
	for {
		time.Sleep(500 * time.Millisecond)
		tryDispatch()
	}
}

func tryDispatch() {
	dispatchMu.Lock()
	defer dispatchMu.Unlock()

	req, hasReq := pq.Peek()
	// Impede processamento de req que não seja pendente
	if !hasReq || req.Status != models.StatusPending {
		return
	}

	drone, hasDrone := state.idleDrone(cfg.baseID)
	if !hasDrone || pq.IsDroneAssigned(drone.ID) {
		return
	}

	state.updateDroneStatus(drone.ID, models.DroneBusy)

	if !acquireLock(req.ID) {
		state.updateDroneStatus(drone.ID, models.DroneIdle)
		return
	}

	payload, _ := json.Marshal(models.DispatchPayload{
		RequestID:   req.ID,
		SectorID:    req.SectorID,
		Description: req.Description,
		Priority:    req.Priority,
		TargetX:     sectorCoordX(req.SectorID),
		TargetY:     sectorCoordY(req.SectorID),
	})

	msg := models.Message{Type: models.MsgDispatch, SenderID: cfg.baseID, LamportTS: clk.Tick(), Payload: payload}

	_, err := network.SendMessageWithReply(drone.Addr, msg)
	if err != nil {
		state.updateDroneStatus(drone.ID, models.DroneIdle)
		state.releaseLock(req.ID)
		broadcastLockRelease(req.ID)
		return
	}

	pq.UpdateStatus(req.ID, models.StatusAssigned, cfg.baseID, drone.ID)
	req.Status = models.StatusAssigned
	req.AssignedTo = drone.ID
	gossipQueueUpdate(req)
}

func acquireLock(reqID string) bool {
	// Tenta trancar localmente primeiro
	if !state.tryLock(reqID, cfg.baseID) {
		return false
	}

	peers := state.onlinePeers()
	if len(peers) == 0 {
		return true
	}

	payload, _ := json.Marshal(models.LockRequestPayload{RequestID: reqID, BaseID: cfg.baseID, LamportTS: clk.Tick()})
	lockMsg := models.Message{Type: models.MsgLockRequest, SenderID: cfg.baseID, LamportTS: clk.Get(), Payload: payload}

	granted := 0
	for _, peer := range peers {
		reply, err := network.SendMessageWithReply(peer.GossipAddr, lockMsg)
		if err != nil {
			continue
		}
		var lockReply models.LockReplyPayload
		if err := json.Unmarshal(reply.Payload, &lockReply); err == nil && lockReply.Granted {
			granted++
		}
	}

	success := (granted == len(peers))

	// CORREÇÃO DO DEADLOCK: Se a gente não conseguiu autorização de TODO MUNDO,
	// temos que SOLTAR o nosso cadeado local e avisar a rede para não travar a missão!
	if !success {
		state.releaseLock(reqID)
		broadcastLockRelease(reqID)
	}

	return success
}

func broadcastLockRelease(reqID string) {
	payload, _ := json.Marshal(models.LockRequestPayload{RequestID: reqID, BaseID: cfg.baseID})
	msg := models.Message{Type: models.MsgLockRelease, SenderID: cfg.baseID, LamportTS: clk.Tick(), Payload: payload}
	network.BroadcastMessage(cfg.peerGossip, msg)
}

func sectorCoordX(sectorID string) float64 {
	coords := map[string]float64{"A": 10, "B": 30, "C": 10, "D": 30}
	if v, ok := coords[sectorID]; ok {
		return v
	}
	return 20
}
func sectorCoordY(sectorID string) float64 {
	coords := map[string]float64{"A": 10, "B": 10, "C": 30, "D": 30}
	if v, ok := coords[sectorID]; ok {
		return v
	}
	return 20
}

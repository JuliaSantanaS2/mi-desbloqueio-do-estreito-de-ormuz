package main

import (
	"encoding/json"
	"net"
	"strings"
	"time"

	"drone-system/internal/models"
	"drone-system/internal/network"
)

func startHBListener() {
	if err := network.StartUDPListener(cfg.hbAddr, handleHeartbeat); err != nil {
		alertMgr.Critical("Listener UDP heartbeat falhou: %v", err)
	}
}

func handleHeartbeat(msg models.Message, from net.Addr) {
	newTS := clk.Update(msg.LamportTS)

	var hb models.HeartbeatPayload
	if err := json.Unmarshal(msg.Payload, &hb); err != nil {
		return
	}

	switch strings.ToLower(hb.NodeType) {
	case "base":
		handleBaseHeartbeat(hb) // Removida a variável solta que causava erro
	case "drone":
		handleDroneHeartbeat(hb)
	case "sensor":
		state.touchSensor(hb.NodeID, newTS)
	case "broker":
		state.touchBroker(hb.NodeID, newTS)
	}
}

func handleBaseHeartbeat(hb models.HeartbeatPayload) {
	// Força maiúsculo para evitar bugs de visualização no Dashboard
	hb.NodeID = strings.ToUpper(hb.NodeID)

	base := models.Base{
		ID:         hb.NodeID,
		SectorID:   strings.ToUpper(hb.SectorID),
		Addr:       hb.Addr,
		GossipAddr: hb.GossipAddr,
		Status:     models.BaseOnline,
		LastSeen:   time.Now(),
	}

	needsSync := false
	existing := state.allPeers()
	found := false

	for _, p := range existing {
		if p.ID == hb.NodeID {
			found = true
			if p.Status == models.BaseOffline {
				needsSync = true
			}
			break
		}
	}

	// Se for uma nova base desconhecida, nós a adicionamos e sincronizamos
	if !found {
		needsSync = true
	}

	state.updatePeer(base)

	if needsSync && hb.Addr != "" {
		alertMgr.OK("Base %s detectada — sincronizando fila", hb.NodeID)
		go sendFullQueueSync(hb.Addr)
	}
}

func handleDroneHeartbeat(hb models.HeartbeatPayload) {
	state.touchDrone(hb.NodeID, hb.BaseID, hb.Status)
}

func broadcastMyHeartbeat() {
	payload := models.HeartbeatPayload{
		NodeType:   "base",
		NodeID:     cfg.baseID,
		SectorID:   cfg.sectorID,
		GossipAddr: cfg.gossipHost,
		Addr:       cfg.baseHost,
	}

	// CORREÇÃO: Removido o `payloadBytes` que o compilador do Go estava reclamando de "not used"
	ts := clk.Tick()
	network.BroadcastHeartbeat(cfg.peerHB, payload, cfg.baseID, ts)
}

func checkPeersHealth() {
	timeout := network.HeartbeatTimeout
	now := time.Now()

	for _, peer := range state.allPeers() {
		if peer.Status == models.BaseOffline {
			continue
		}
		if now.Sub(peer.LastSeen) > timeout {
			state.markPeerOffline(peer.ID)
			alertMgr.Critical("Base %s OFFLINE", peer.ID)
		}
	}
	checkDroneHealth()
	balanceDrones() // LIGADO DE NOVO!
}

func checkDroneHealth() {
	timeout := network.HeartbeatTimeout
	now := time.Now()

	for _, drone := range state.allDrones() {
		if drone.Status == models.DroneLost {
			continue
		}
		if now.Sub(drone.LastSeen) > timeout {
			alertMgr.Critical("Drone %s LOST", drone.ID)
			state.updateDroneStatus(drone.ID, models.DroneLost)

			if drone.Status == models.DroneBusy {
				recoverBusyDroneMission(drone)
			}
		}
	}
}

func recoverBusyDroneMission(drone models.Drone) {
	all := pq.GetAll()
	for _, req := range all {
		if req.AssignedTo == drone.ID && (req.Status == models.StatusAssigned) {

			// Força o pedido a ir para o topo absoluto da fila
			req.Priority = -1
			req.LamportTS = 0

			// 1. Remove textos antigos para não acumular "NORMAL" ou múltiplos "[FALHA]"
			desc := req.Description
			desc = strings.TrimPrefix(desc, "NORMAL - ")
			desc = strings.TrimPrefix(desc, "CRITICO - ")
			desc = strings.TrimPrefix(desc, "[FALHA] ")
			desc = strings.TrimPrefix(desc, "FALHA - ")

			// 2. Muda o Tipo para acionar o CSS de badge vermelho no painel
			req.Type = models.RequestType("FALHA")

			// 3. Formata exatamente do jeito que você pediu!
			req.Description = "FALHA - " + desc

			// Libera as propriedades de Lock
			req.Status = models.StatusPending
			req.AssignedTo = ""
			req.LockedBy = ""

			// Atualiza na memória local
			pq.Replace(req)
			state.releaseLock(req.ID)

			// 4. O SEGREDO (DEADLOCK FIX): Avisa IMEDIATAMENTE as outras bases que
			// nós soltamos o lock! Agora qualquer drone livre pode assumir o resgate.
			go broadcastLockRelease(req.ID)

			// Propaga a fila atualizada com o novo status e descrição
			gossipQueueUpdate(req)
			break
		}
	}
}

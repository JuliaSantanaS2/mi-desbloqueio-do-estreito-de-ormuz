package main

import (
	"drone-system/internal/models"
	"drone-system/internal/network"
	"encoding/json"
	"net"
	"time"
)

func handleDroneRegister(conn net.Conn, msg models.Message) {
	var reg models.RegisterPayload
	if err := json.Unmarshal(msg.Payload, &reg); err != nil {
		return
	}

	drone := models.Drone{
		ID:       reg.DroneID,
		BaseID:   cfg.baseID,
		SectorID: cfg.sectorID,
		Status:   models.DroneIdle,
		X:        reg.X,
		Y:        reg.Y,
		LastSeen: time.Now(),
		Addr:     reg.Addr,
	}

	state.registerDrone(drone)
	network.WriteMessage(conn, models.Message{Type: models.MsgRegister, SenderID: cfg.baseID, LamportTS: clk.Tick()})
	go propagateDroneInfo(drone)
}

func handleMissionDone(msg models.Message) {
	var done models.MissionDonePayload
	if err := json.Unmarshal(msg.Payload, &done); err != nil {
		return
	}

	state.updateDroneStatus(done.DroneID, models.DroneIdle)
	state.updateDroneMissionDesc(done.DroneID, "")

	if d, ok := state.getDrone(done.DroneID); ok {
		go propagateDroneInfo(d)
	}

	pq.UpdateStatus(done.RequestID, models.StatusDone, cfg.baseID, done.DroneID)
	pq.Remove(done.RequestID)
	state.releaseLock(done.RequestID)
	go broadcastLockRelease(done.RequestID)

	req := models.Request{ID: done.RequestID, Status: models.StatusDone, AssignedTo: done.DroneID, LockedBy: cfg.baseID}
	go gossipQueueUpdate(req)
}

func handleDroneStatusUpdate(msg models.Message) {
	var update models.DroneStatusPayload
	if err := json.Unmarshal(msg.Payload, &update); err != nil {
		return
	}

	state.updateDroneMissionDesc(update.DroneID, update.MissionDesc)
	if d, ok := state.getDrone(update.DroneID); ok {
		go propagateDroneInfo(d)
	}
}

func propagateDroneInfo(drone models.Drone) {
	payload, _ := json.Marshal(drone)
	msg := models.Message{Type: models.MsgDroneInfo, SenderID: cfg.baseID, LamportTS: clk.Tick(), Payload: payload}
	network.BroadcastMessage(cfg.peerBases, msg)
}

func balanceDrones() {
	myCount := 0
	var myIdleDrones []models.Drone
	for _, d := range state.allDrones() {
		if d.BaseID == cfg.baseID && d.Status != models.DroneLost {
			myCount++
			if d.Status == models.DroneIdle {
				myIdleDrones = append(myIdleDrones, d)
			}
		}
	}
	if len(myIdleDrones) == 0 {
		return
	}

	var poorestPeer models.Base
	minDrones := myCount
	for _, peer := range state.onlinePeers() {
		count := 0
		for _, d := range state.allDrones() {
			if d.BaseID == peer.ID && d.Status != models.DroneLost {
				count++
			}
		}
		if count < minDrones {
			minDrones = count
			poorestPeer = peer
		}
	}

	// CORREÇÃO: Voltando a matemática para +1 para distribuir igualitariamente!
	if poorestPeer.ID != "" && myCount > (minDrones+1) {
		droneToMove := myIdleDrones[0]
		state.updateDroneStatus(droneToMove.ID, models.DroneLost)
		payload, _ := json.Marshal(models.ReassignPayload{NewBaseID: poorestPeer.ID, NewBaseAddr: poorestPeer.Addr})
		msg := models.Message{Type: models.MsgReassign, SenderID: cfg.baseID, LamportTS: clk.Tick(), Payload: payload}
		network.SendMessage(droneToMove.Addr, msg)
	}
}

func init() {
	_ = handleDroneRegister
	_ = handleMissionDone
}
